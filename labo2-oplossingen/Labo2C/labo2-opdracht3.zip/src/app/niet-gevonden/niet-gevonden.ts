import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-niet-gevonden',
  imports: [RouterLink],
  templateUrl: './niet-gevonden.html',
  styleUrl: './niet-gevonden.css',
})
export class NietGevonden {}
